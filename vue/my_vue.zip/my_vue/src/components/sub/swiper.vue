<template>
    <div class="app-swipe">
        
    </div>
</template>

<script>
    
</script>

<style>
    
</style>